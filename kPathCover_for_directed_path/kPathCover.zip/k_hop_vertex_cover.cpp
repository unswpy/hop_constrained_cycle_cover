#include "k_hop_vertex_cover.h"
set<NODE_TYPE> k_hop_vertex_cover(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse, int k, NODE_TYPE node_num) {
	//copy adjacency_list
	vector<NODE_TYPE>* adjacency_list_temp = new vector<NODE_TYPE>[node_num+1];
	for (NODE_TYPE i = 0; i < node_num; i++)
	{
		vector<NODE_TYPE> temp(adjacency_list[i]);
		adjacency_list_temp[i].swap(temp);
	}
	set<NODE_TYPE> result;
	vector<hot_degree> hot_points;
	//double threhold = 0.05;//this means we find top 5% nodes in degree rank as hot-points(this part can change to k-core value, truess value or centrality)
	for (NODE_TYPE i = 0; i < node_num; i++)
	{
		NODE_TYPE temp_degree = adjacency_list[i].size()  + adjacency_list_reverse[i].size();// sum in and out degree
		if (temp_degree != 0)
		{
			hot_degree hd1(i, temp_degree);
			hot_points.push_back(hd1);
		}
	}
	stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
	for (NODE_TYPE j = 0; j < node_num; j++)
	{
		NODE_TYPE i = hot_points[j].node;
		//cout << i << endl;
		if (adjacency_list[i].size() == 0)
		{
			continue;
		}
		vector<NODE_TYPE> temp_k_path;
		vector<NODE_TYPE> c_path;
		if (find_k_path_from_node1(adjacency_list_temp, k, i, node_num, c_path, 0, temp_k_path))
		{//find a k_path, then push all the nodes in the k-path into result set and remove all the edges in and out from these nodes
			
			//// cout << "temp_k_path :";
			//for (auto iter1 = temp_k_path.begin(); iter1 != temp_k_path.end(); iter1++)
			//{
			//	// cout << *iter1 << " : ";
			//}
			//// cout << endl;
			for (auto cover_node = temp_k_path.begin(); cover_node != temp_k_path.end(); cover_node++)
			{
				result.insert(*cover_node);
				vector<NODE_TYPE> temp_v;
				adjacency_list_temp[*cover_node].swap(temp_v);//delete outgoing edges
				//start to delete in going edges
				for (auto in_node = adjacency_list_reverse[*cover_node].begin(); in_node != adjacency_list_reverse[*cover_node].end(); in_node++) {
					delete_adjacency_list_with_specific_edge(adjacency_list_temp, *cover_node, *in_node);
				}
			}
		}
	}
	delete[] adjacency_list_temp;
	return result;
}

bool delete_adjacency_list_with_specific_edge(vector<NODE_TYPE>* adjacency_list, NODE_TYPE node1, NODE_TYPE node2) {
	bool result = false;
	for (auto iter = adjacency_list[node2].begin(); iter != adjacency_list[node2].end(); )
	{
		if (*iter == node1)
		{
			iter = adjacency_list[node2].erase(iter);
			result = true;
		}
		else
		{
			iter++;
		}
	}
	return result;
}


bool find_k_path_from_node1(vector<NODE_TYPE>* adjacency_list, int k, NODE_TYPE node1, NODE_TYPE node_num, vector<NODE_TYPE>& c_path, int cur_distance,vector<NODE_TYPE>& result)//, set<NODE_TYPE>& block_nodes) 
{
	bool find_k_path_yet = false;
	//if node1 is already in c_path, then return false
	for (auto iter = c_path.begin(); iter != c_path.end(); iter++)
	{
		if (*iter == node1)
		{
			return false;
		}
	}
	c_path.push_back(node1);
	if (cur_distance >= k)
	{
		vector<NODE_TYPE> temp(c_path);
		result.swap(temp);
		c_path.pop_back();
		return true;
	}
	for (auto iter = adjacency_list[node1].begin(); iter != adjacency_list[node1].end(); iter++)
	{
		find_k_path_yet = find_k_path_from_node1(adjacency_list, k, *iter, node_num, c_path, cur_distance + 1, result);
		if (find_k_path_yet)
		{
			break;
		}
	}
	c_path.pop_back();
	return find_k_path_yet;
}


NODE_TYPE find_result_node_in_single_k_path(vector<NODE_TYPE> temp_k_path, int* find_times)
{
	NODE_TYPE temp_index = temp_k_path.size() / 2;
	NODE_TYPE temp_max = find_times[temp_k_path[temp_index]];
	NODE_TYPE temp_max_index = temp_index;
	NODE_TYPE left, right;
	left = temp_index - 1;
	right = temp_index;
	while (left >= 0 )
	{
		if (left >= 0)
		{
			if (find_times[temp_k_path[left]] > temp_max) {
				temp_max_index = left;
				temp_max = find_times[temp_k_path[left]];
			}
			left--;
		}
	}
	while (right < temp_k_path.size())
	{
		if (right < temp_k_path.size())
		{
			if (find_times[temp_k_path[right]] > temp_max) {
				temp_max_index = right;
				temp_max = find_times[temp_k_path[right]];
			}
			right++;
		}
	}
	return temp_k_path[temp_max_index];
}

set<NODE_TYPE> k_hop_vertex_cover_heuristic(vector<NODE_TYPE>* adjacency_list, vector<NODE_TYPE>* adjacency_list_reverse, int k, NODE_TYPE node_num)
{
	//copy adjacency_list
	int* find_times = new int[node_num+1];
	vector<NODE_TYPE>* adjacency_list_temp = new vector<NODE_TYPE>[node_num + 1];
	for (NODE_TYPE i = 0; i < node_num; i++)
	{
		find_times[i] = 0;
		vector<NODE_TYPE> temp(adjacency_list[i]);
		adjacency_list_temp[i].swap(temp);
	}
	set<NODE_TYPE> result;
	vector<hot_degree> hot_points;
	//double threhold = 0.05;//this means we find top 5% nodes in degree rank as hot-points(this part can change to k-core value, truess value or centrality)
	for (NODE_TYPE i = 0; i < node_num; i++)
	{
		NODE_TYPE temp_degree = adjacency_list[i].size()  + adjacency_list_reverse[i].size();// sum in and out degree
		if (temp_degree != 0)
		{
			hot_degree hd1(i, temp_degree);
			hot_points.push_back(hd1);
		}
	}
	stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
	set<NODE_TYPE> second_iter;
	for (NODE_TYPE j = 0; j < node_num; j++)
	{
		NODE_TYPE i = hot_points[j].node;
		if (find_times[i] != 0) 
		{
			second_iter.insert(i);
			continue;
		}
		if(i % 10000 == 0) cout << i << endl;
		if (adjacency_list[i].size() == 0)
		{
			continue;
		}
		vector<NODE_TYPE> temp_k_path;
		vector<NODE_TYPE> c_path;
		if (find_k_path_from_node1(adjacency_list, k, i, node_num, c_path, 0, temp_k_path))
		{//find a k_path, then push all the nodes in the k-path into result set and remove all the edges in and out from these nodes

		 //// cout << "temp_k_path :";
		 //for (auto iter1 = temp_k_path.begin(); iter1 != temp_k_path.end(); iter1++)
		 //{
		 //	// cout << *iter1 << " : ";
		 //}
		 //// cout << endl;

			for (auto cover_node = temp_k_path.begin(); cover_node != temp_k_path.end(); cover_node++)
			{
				find_times[*cover_node]++;
			}
			NODE_TYPE reuslt_node = find_result_node_in_single_k_path(temp_k_path,find_times);
			result.insert(reuslt_node);
			vector<NODE_TYPE> temp_v;
			adjacency_list_temp[reuslt_node].swap(temp_v);//delete outgoing edges
														  //start to delete in going edges
			for (auto in_node = adjacency_list_reverse[reuslt_node].begin(); in_node != adjacency_list_reverse[reuslt_node].end(); in_node++) {
				delete_adjacency_list_with_specific_edge(adjacency_list_temp, reuslt_node, *in_node);
			}


		}
	}
	//second iter
	for (auto iter = second_iter.begin(); iter != second_iter.end(); iter++)
	{
		NODE_TYPE i = *iter;

		if (i % 10000 == 0) cout << i << endl;
		if (adjacency_list[i].size() == 0)
		{
			continue;
		}
		vector<NODE_TYPE> temp_k_path;
		vector<NODE_TYPE> c_path;
		if (find_k_path_from_node1(adjacency_list, k, i, node_num, c_path, 0, temp_k_path))
		{//find a k_path, then push all the nodes in the k-path into result set and remove all the edges in and out from these nodes

		 //// cout << "temp_k_path :";
		 //for (auto iter1 = temp_k_path.begin(); iter1 != temp_k_path.end(); iter1++)
		 //{
		 //	// cout << *iter1 << " : ";
		 //}
		 //// cout << endl;

			for (auto cover_node = temp_k_path.begin(); cover_node != temp_k_path.end(); cover_node++)
			{
				find_times[*cover_node]++;
			}
			NODE_TYPE reuslt_node = find_result_node_in_single_k_path(temp_k_path, find_times);
			result.insert(reuslt_node);
			vector<NODE_TYPE> temp_v;
			adjacency_list_temp[reuslt_node].swap(temp_v);//delete outgoing edges
														  //start to delete in going edges
			for (auto in_node = adjacency_list_reverse[reuslt_node].begin(); in_node != adjacency_list_reverse[reuslt_node].end(); in_node++) {
				delete_adjacency_list_with_specific_edge(adjacency_list_temp, reuslt_node, *in_node);
			}


		}
	}
	delete[] adjacency_list_temp;
	delete[] find_times;
	return result;
}


void test_k_hop_cover(int k, char* dataset, char* algorithm)
{//algorithms includes 
	char temp_algorithms[50][50] = { "induced_dag_meetnodes","dfsbaseline","double_bfs_baseline","induced_dag_dfs" };
	vector<NODE_TYPE> map_node_to_total_order;
	//int option = 0;// 0 means use dynamic files to test
	//double threshold1 = 0.0001;//hot points threshold
	//double threshold2 = 0.0010;//label nodes threshold
	//int k = 5;
	// 1 means test with given query_node1 and query_node2
	int testi = 10;
	ofstream test;
	//test.open("Amazon_result\\hp_result" + to_string(testi));
	//test << "test " << endl;


	ifstream count_file;
	ofstream output;
	ifstream inEdges;
	string outfile = dataset;
	outfile += "_result";
	NODE_TYPE  node_num;// = 548552; //121790;// 548552; //1007518272;//548552;//1234944765;
						//NODE_TYPE node_num = 91306;
	string count_name = dataset;
	count_file.open(count_name);
	output.open(outfile);
	char tmp[BUFFER_LENTH];

	if (!count_file.is_open())
	{
		cout << "Error opening file : " << dataset << endl;
	}
	//configure the values of n and m 
	node_num = 0;
	int i = 0;
	NODE_TYPE x, y;
	while (!count_file.eof())
	{
		NODE_TYPE x, y;
		count_file.getline(tmp, BUFFER_LENTH);
		if (tmp[0] != 'a') continue;
		extractEdgesSkipNodes(tmp, x, y,1);
		i++;
		if (i <= 10)
		{
			cout << x << " : " << y << endl;
		}
		if (x > node_num)
		{
			node_num = x;
		}
		if (y > node_num)
		{
			node_num = y;
		}
		//adjacency_list[x].push_back(y);//directed graph, so we only push edge x y NODE_TYPE o x's adjacency list
		//adjacency_list_reverse[y].push_back(x);
		//adjacency_list[y].push_back(x);
	}
	//de_num++;
	node_num++;
	cout << node_num << " is the load node num " << endl;
	count_file.close();



	vector<int> in_degrees, out_degrees;// we need to get in and out degrees
	vector<NODE_TYPE >* adjacency_list = new vector<NODE_TYPE >[node_num + 1];
	vector<NODE_TYPE >* adjacency_list_reverse = new vector<NODE_TYPE >[node_num + 1];
	vector<NODE_TYPE >* adjacency_list_double = new vector<NODE_TYPE>[node_num + 1];//record the double directed adjacency for the undirected graph load 

	string temp_static(dataset);

	load_graph_data(temp_static, adjacency_list, adjacency_list_reverse);
	set<NODE_TYPE> result1, result2;
	clock_t t1,t2,t3;
	t1 = clock();
	result1 = k_hop_vertex_cover_heuristic(adjacency_list, adjacency_list_reverse, k, node_num);
	t2 = clock();
	cout << "baseline:\t" << result2.size() << "\t ours : \t" << result1.size() << endl;
	cout << "runtime:ours\t" << double(t2 - t1) / CLOCKS_PER_SEC << endl;
	cout << "ours done" << endl;
	output << "baseline:\t" << result2.size() << "\t ours : \t" << result1.size() << endl;
	output << "runtime:ours\t" << double(t2 - t1) / CLOCKS_PER_SEC << endl;
	output << "ours done" << endl;
	result2 = k_hop_vertex_cover(adjacency_list, adjacency_list_reverse, k, node_num);
	t3 = clock();
	cout << "baseline:\t" << result2.size() <<"\t ours : \t" << result1.size() << endl;
	cout << "runtime:ours\t" << double(t2 - t1) / CLOCKS_PER_SEC << "\t baseline : \t" << double(t3 - t2) / CLOCKS_PER_SEC << endl;
	output << "baseline:\t" << result2.size() << "\t ours : \t" << result1.size() << endl;
	output << "runtime:ours\t" << double(t2 - t1) / CLOCKS_PER_SEC << "\t basline : \t" << double(t3 - t2) / CLOCKS_PER_SEC << endl;

	system("pause");
	output.close();
}
