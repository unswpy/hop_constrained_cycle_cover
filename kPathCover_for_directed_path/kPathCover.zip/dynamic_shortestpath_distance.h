#pragma once
#include "graph.h"
//spd means shortest path distance
